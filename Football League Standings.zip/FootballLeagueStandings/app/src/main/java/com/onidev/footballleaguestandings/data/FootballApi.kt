package com.onidev.footballleaguestandings.data

import com.onidev.footballleaguestandings.BuildConfig
import com.onidev.footballleaguestandings.response.Standings.StandingsResponse
import com.onidev.footballleaguestandings.response.detailTeam.DetailTeamResponse
import com.onidev.footballleaguestandings.response.listAreas.AreaResponse
import com.onidev.footballleaguestandings.response.listLeague.LeagueResponse
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Path
import retrofit2.http.Query

interface FootballApi {

    @GET("areas/")
    suspend fun getAreas(
        @Header("X-Auth-Token") apiKey:String = BuildConfig.APIKEY
    ): AreaResponse

    @GET("competitions/")
    suspend fun getCompetition(
        //TODO safe APIKEY
        @Header("X-Auth-Token") apiKey:String = BuildConfig.APIKEY,
        @Query("areas") areaId: Int
    ):LeagueResponse

    @GET("competitions/{code}/standings")
    suspend fun getStandings(
        @Header("X-Auth-Token") apiKey:String = BuildConfig.APIKEY,
        @Path("code") code : Int
    ):StandingsResponse

    @GET("teams/{teamId}")
    suspend fun getDetailTeam(
        @Header("X-Auth-Token") apiKey:String = BuildConfig.APIKEY,
        @Path("teamId") teamId : Int
    ):DetailTeamResponse

//    companion object {
//        const val BASE_URL = "https://api.football-data.org/v4/"
//        fun create(): FootballApi {
//            return Retrofit.Builder()
//                .baseUrl(BASE_URL)
//                .addConverterFactory(GsonConverterFactory.create())
//                .build()
//                .create(FootballApi::class.java)
//        }
//    }
}