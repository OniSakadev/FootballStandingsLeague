package com.onidev.footballleaguestandings.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.onidev.footballleaguestandings.local.entity.User

@Dao
interface UserDao {

    @Update
    suspend fun updateUser(user: User)

    @Query("SELECT + FROM user Where userName = :name")
    suspend fun getUser(name: String): User

    @Insert
    suspend fun insertUser(user: User)
}