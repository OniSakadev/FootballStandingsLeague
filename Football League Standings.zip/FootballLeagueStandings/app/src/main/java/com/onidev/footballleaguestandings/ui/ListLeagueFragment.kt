package com.onidev.footballleaguestandings.ui

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import com.onidev.footballleaguestandings.R
import com.onidev.footballleaguestandings.adapter.LeagueAdapter
import com.onidev.footballleaguestandings.databinding.FragmentListLeagueBinding
import com.onidev.footballleaguestandings.viewModel.LeagueViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ListLeagueFragment : Fragment(R.layout.fragment_list_league) {

    private val viewModel: LeagueViewModel by activityViewModels()
    private val binding: FragmentListLeagueBinding by viewBinding()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

//        val leagueId = arguments?.getInt(KEY_LIST_LEAGUE) ?: 0

        viewModel.whenLoading.observe(viewLifecycleOwner) {
            binding.progressIndicator.isVisible = it
        }

        binding.topAppBar.setOnMenuItemClickListener {
            when(it.itemId){
                R.id.setting -> {
                    findNavController().navigate(R.id.action_listLeague_to_fragmentSetting3)
                }
            }
            when(it.itemId){
                R.id.favorite -> {
                    findNavController().navigate(R.id.action_listLeague_to_favoriteTeamFragment)
                }
            }
            true
        }

        binding.swipe.setOnRefreshListener {
            getData()
        }

        binding.topAppBar.setOnClickListener{
            findNavController().navigateUp()
        }
        getData()
    }

    fun getData() {
        viewModel.getLeague()
        viewModel.leagueList.observe(viewLifecycleOwner) {
            if (it == null) {
                Toast.makeText(requireContext(), "Oops!, something wring", Toast.LENGTH_SHORT).show()
            } else {
                val adapter = LeagueAdapter(it)
                binding.rvListLeague.adapter = adapter
                adapter.itemClickListener = {
                    val bundle = bundleOf(StandingsLeagueFragment.KEY_LIST_STANDINGS to it.id)
                    findNavController().navigate(R.id.action_listLeague_to_standingsLeague, bundle)
                }
            }
            binding.swipe.isRefreshing = false
        }
    }

    companion object {
        const val KEY_LIST_LEAGUE = "key_list_league"
    }
}