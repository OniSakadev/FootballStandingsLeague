package com.onidev.footballleaguestandings.repository

import com.onidev.footballleaguestandings.data.FootballApi
import com.onidev.footballleaguestandings.local.FavoriteDatabase
import com.onidev.footballleaguestandings.local.entity.Favorite
import com.onidev.footballleaguestandings.response.Standings.StandingsResponse
import com.onidev.footballleaguestandings.response.detailTeam.DetailTeamResponse
import com.onidev.footballleaguestandings.response.listAreas.AreaResponse
import com.onidev.footballleaguestandings.response.listLeague.LeagueResponse
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class FootballRepository @Inject constructor(
    private val footballApi: FootballApi,
    val database: FavoriteDatabase
    ) {


    suspend fun getAreas(
        apiKey:String
    ): AreaResponse = footballApi.getAreas(apiKey)

    suspend fun getCompetition(
        apiKey:String,
        areaId: Int
    ): LeagueResponse = footballApi.getCompetition(apiKey,areaId)

    suspend fun getStandings(
        apiKey:String,
        code : Int
    ): StandingsResponse = footballApi.getStandings(apiKey,code)

    suspend fun getDetailTeam(
        apiKey:String,
        teamId : Int
    ): DetailTeamResponse = footballApi.getDetailTeam(apiKey,teamId)

    suspend fun insertFavorite(favorite: Favorite) {
        return database.favoriteDao().insertFavorite(favorite)
    }

    suspend fun deleteFavorite(favorite: Favorite) {
        return database.favoriteDao().deleteFavorite(favorite)
    }

    suspend fun getFavorite(): Flow<List<Favorite>> {
        return database.favoriteDao().getFavorite()
    }

    suspend fun getFavorite(id: Int): Favorite? {
        return database.favoriteDao().getFavorite(id)
    }

}