package com.onidev.footballleaguestandings.viewModel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.onidev.footballleaguestandings.BuildConfig
import com.onidev.footballleaguestandings.local.entity.Favorite
import com.onidev.footballleaguestandings.repository.FootballRepository
import com.onidev.footballleaguestandings.response.detailTeam.DetailTeamResponse
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DetailTeamViewModel @Inject constructor(private val footballRepository: FootballRepository): ViewModel() {

    //TODO MVVM Repository
//    private val api: FootballApi = FootballApi.create()

    private val _detailTeam: MutableLiveData<DetailTeamResponse?> = MutableLiveData()
    val detailTeam: MutableLiveData<DetailTeamResponse?> = _detailTeam

    private val _whenLoading: MutableLiveData<Boolean> = MutableLiveData()
    val whenLoading: MutableLiveData<Boolean> = _whenLoading

    fun getDetail(id: Int) {
        viewModelScope.launch {
            _whenLoading.value = true
            try {
                val response = footballRepository.getDetailTeam(apiKey = BuildConfig.APIKEY, teamId = id)
                _detailTeam.value = response
//                Log.d("succes","berhasil")
            }catch (e: Exception) {
//                Log.d("failure","gagal${e.message}")
                _detailTeam.value = null
            }finally {
                _whenLoading.value = false
            }
        }
    }

    suspend fun getData(id: Int): Favorite? {
        return footballRepository.getFavorite(id)
    }

    suspend fun getInsert(favorite : Favorite) {
        return footballRepository.insertFavorite(favorite)
    }

    suspend fun getDelete(favorite: Favorite) {
        return footballRepository.deleteFavorite(favorite)
    }
}