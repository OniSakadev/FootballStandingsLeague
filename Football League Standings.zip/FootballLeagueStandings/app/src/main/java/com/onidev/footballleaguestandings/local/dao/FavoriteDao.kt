package com.onidev.footballleaguestandings.local.dao

import androidx.room.*
import com.onidev.footballleaguestandings.local.entity.Favorite
import kotlinx.coroutines.flow.Flow

@Dao
interface FavoriteDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(favorite: Favorite)

    @Delete
    suspend fun deleteFavorite(favorite: Favorite)

    @Query("SELECT * FROM favorite")
    fun getFavorite(): Flow<List<Favorite>>

    @Query("SELECT * FROM favorite WHERE id = :id")
    suspend fun getFavorite(id:Int): Favorite?

}