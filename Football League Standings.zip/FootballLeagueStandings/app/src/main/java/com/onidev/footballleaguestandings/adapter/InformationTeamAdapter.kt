package com.onidev.footballleaguestandings.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import by.kirich1409.viewbindingdelegate.viewBinding
import com.onidev.footballleaguestandings.R
import com.onidev.footballleaguestandings.databinding.ItemPlayerBinding
import com.onidev.footballleaguestandings.response.detailTeam.DetailTeamResponse
import com.onidev.footballleaguestandings.response.detailTeam.Squad

class InformationTeamAdapter(private val teamResponse: DetailTeamResponse): RecyclerView.Adapter<InformationTeamAdapter.TeamViewHolder>() {

    private var itemClickListener:((Squad) -> Unit)? = null

    class TeamViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        private val binding: ItemPlayerBinding by viewBinding()

        fun bindView(item: Squad) = with(binding) {
//            binding.imgFacePlayer.load(item){
//                placeholder(R.drawable.empty_face)
//                error(R.drawable.question_mark)
//            }
            txtPlayerName.text = item.name
            txtCountry.text = item.nationality
            txtPosition.text = item.position
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TeamViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_player, parent, false)
        return TeamViewHolder(view)
    }

    override fun getItemCount(): Int {
        return teamResponse.squad.size
    }

    override fun onBindViewHolder(holder: TeamViewHolder, position: Int) {
        val item = teamResponse.squad[position]
        holder.bindView(item)
        holder.itemView.setOnClickListener{
            itemClickListener?.invoke(item)
        }
    }
}