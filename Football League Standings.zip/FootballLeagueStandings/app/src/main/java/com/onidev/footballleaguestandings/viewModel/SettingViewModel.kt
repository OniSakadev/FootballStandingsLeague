package com.onidev.footballleaguestandings.viewModel

class SettingViewModel {
}