package com.onidev.footballleaguestandings.ui

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import coil.load
import com.onidev.footballleaguestandings.R
import com.onidev.footballleaguestandings.databinding.FragmentDetailFavoriteBinding
import com.onidev.footballleaguestandings.local.entity.Favorite

class DetailFavoriteFragment : Fragment(R.layout.fragment_detail_favorite) {

    private val binding: FragmentDetailFavoriteBinding by viewBinding()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val data = arguments?.getParcelable<Favorite>(KEY_DATA)
        data?.let {
            binding.titleTeam.text = it.name
            binding.imageLogoDetail.load(it.logo)
            binding.venueTeam.text = it.venue
        }

        binding.topAppBar.setOnMenuItemClickListener {
            when(it.itemId){
                R.id.setting -> {
                    findNavController().navigate(R.id.action_detailFavoriteFragment_to_fragmentSetting3)
                }
            }
            when(it.itemId){
                R.id.favorite -> {
                    findNavController().navigate(R.id.action_detailFavoriteFragment_to_favoriteTeamFragment)
                }
            }
            true
        }

        binding.topAppBar.setOnClickListener{
            findNavController().navigateUp()
        }
    }
    companion object{
        const val KEY_DATA = "key_data"
    }
}