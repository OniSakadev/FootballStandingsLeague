package com.onidev.footballleaguestandings.response.listAreas


import com.google.gson.annotations.SerializedName

data class AreaResponse(
    @SerializedName("areas")
    val areas: List<Area>,
    @SerializedName("count")
    val count: Int,
    @SerializedName("filters")
    val filters: Filters
)