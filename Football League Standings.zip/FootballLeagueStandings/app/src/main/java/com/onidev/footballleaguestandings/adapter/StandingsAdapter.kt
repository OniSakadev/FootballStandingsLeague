package com.onidev.footballleaguestandings.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import by.kirich1409.viewbindingdelegate.viewBinding
import com.onidev.footballleaguestandings.R
import com.onidev.footballleaguestandings.databinding.ItemListBinding
import com.onidev.footballleaguestandings.response.Standings.StandingsResponse
import com.onidev.footballleaguestandings.response.Standings.Table

class StandingsAdapter(private val standingsResponse: StandingsResponse): RecyclerView.Adapter<StandingsAdapter.StandingsViewHolder>() {

    var itemClickListener:((Int) -> Unit)? = null

    class StandingsViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        val binding : ItemListBinding by viewBinding()

        fun bindView(item: Table) = with(binding) {
            teamName.text = item.team.name
            totalMatch.text = item.playedGames.toString()
            winTeam.text = item.won.toString()
            drawTeam.text = item.draw.toString()
            loseTeam.text = item.lost.toString()
            pointTeam.text = item.points.toString()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StandingsViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_list, parent, false)
        return StandingsViewHolder(view)
    }

    override fun getItemCount(): Int {
        return standingsResponse.standings[0].table.size
    }

    override fun onBindViewHolder(holder: StandingsViewHolder, position: Int) {
        val standing = standingsResponse.standings[0]
        val item = standing.table[position]
        holder.binding.number.text = "${position + 1}"
        holder.binding.teamName.setOnClickListener{
            itemClickListener?.invoke(item.team.id)
        }
        holder.bindView(item)
//        holder.itemView.setOnClickListener{
//            itemClickListener?.invoke()
//        }
    }
}