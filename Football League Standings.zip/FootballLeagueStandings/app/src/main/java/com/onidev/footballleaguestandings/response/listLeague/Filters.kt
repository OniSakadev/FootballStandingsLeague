package com.onidev.footballleaguestandings.response.listLeague


import com.google.gson.annotations.SerializedName

data class Filters(
    @SerializedName("areas")
    val areas: List<Int>,
    @SerializedName("client")
    val client: String
)