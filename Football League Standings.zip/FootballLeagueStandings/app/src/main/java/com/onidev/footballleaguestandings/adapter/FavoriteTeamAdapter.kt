package com.onidev.footballleaguestandings.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import by.kirich1409.viewbindingdelegate.viewBinding
import coil.load
import com.onidev.footballleaguestandings.R
import com.onidev.footballleaguestandings.databinding.ItemFavoriteBinding
import com.onidev.footballleaguestandings.local.entity.Favorite

class FavoriteTeamAdapter(val favoriteTeam: List<Favorite>): RecyclerView.Adapter<FavoriteTeamAdapter.FavoriteViewHolder>() {

    var itemClickListener: ((Favorite) -> Unit)? = null

    var removeFav: ((Favorite) -> Unit)? = null

    class FavoriteViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val binding: ItemFavoriteBinding by viewBinding()
        fun bindView(item: Favorite) {
            with(binding){
                binding.imgFavorite.load(item.logo)
                txtFavorite.text = item.name
            }
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoriteViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_favorite, parent, false)
        return FavoriteViewHolder(view)
    }

    override fun getItemCount(): Int {
        return favoriteTeam.size
    }

    override fun onBindViewHolder(holder: FavoriteViewHolder, position: Int) {
        val favView = favoriteTeam[position]
        holder.bindView(favView)
        holder.binding.cvFav.setOnClickListener{
            itemClickListener?.invoke(favView)
        }
        holder.binding.removeFavorite.setOnClickListener{
            removeFav?.invoke(favView)
        }
    }
}