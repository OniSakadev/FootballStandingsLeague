package com.onidev.footballleaguestandings.response.Standings


import com.google.gson.annotations.SerializedName

data class Filters(
    @SerializedName("season")
    val season: String
)