package com.onidev.footballleaguestandings.onboarding

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import by.kirich1409.viewbindingdelegate.viewBinding
import com.onidev.footballleaguestandings.R
import com.onidev.footballleaguestandings.databinding.FragmentViewPagerBinding
import com.onidev.footballleaguestandings.onboarding.screens.FirstScreen
import com.onidev.footballleaguestandings.onboarding.screens.SecondScreen

class ViewPagerFragment : Fragment(R.layout.fragment_view_pager) {

    val binding: FragmentViewPagerBinding by viewBinding()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val fragmentList = arrayListOf<Fragment>(
            FirstScreen(),
            SecondScreen()
        )

        val adapter = ViewPagerAdapter(
            fragmentList,
            requireActivity().supportFragmentManager,
            lifecycle
        )

        binding.viewPager.adapter = adapter
        binding.viewPager.isUserInputEnabled = false
    }
}