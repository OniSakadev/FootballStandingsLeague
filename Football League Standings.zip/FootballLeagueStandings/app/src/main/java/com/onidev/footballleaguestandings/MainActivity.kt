package com.onidev.footballleaguestandings

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.view.isVisible
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupWithNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import com.onidev.footballleaguestandings.databinding.ActivityMainBinding
import com.google.android.material.appbar.MaterialToolbar
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity(R.layout.activity_main) {

    private val binding: ActivityMainBinding by viewBinding()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val navView: MaterialToolbar = binding.topAppBar

        val navController = findNavController(R.id.nav_host_fragment_activity_main)
        navController.addOnDestinationChangedListener{ _,id,_ ->
            navView.isVisible = id.id != R.id.viewPagerFragment
            navView.isVisible = id.id != R.id.listCountry
        }
        setSupportActionBar(binding.topAppBar)

        val appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.listCountry,R.id.listLeague,R.id.standingsLeague,R.id.informationTeam,R.id.fragmentSetting3
            )
        )
//        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)
        binding.topAppBar.setupWithNavController(navController, appBarConfiguration)
    }
}
