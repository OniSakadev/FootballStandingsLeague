package com.onidev.footballleaguestandings.response.listAreas


import com.google.gson.annotations.SerializedName

data class Area(
    @SerializedName("countryCode")
    val countryCode: String,
    @SerializedName("flag")
    val flag: String,
    @SerializedName("id")
    val id: Int,
    @SerializedName("name")
    val name: String,
    @SerializedName("parentArea")
    val parentArea: String,
    @SerializedName("parentAreaId")
    val parentAreaId: Int
)