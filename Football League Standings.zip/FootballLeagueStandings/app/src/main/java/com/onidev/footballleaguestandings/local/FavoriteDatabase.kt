package com.onidev.footballleaguestandings.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.onidev.footballleaguestandings.local.dao.FavoriteDao
import com.onidev.footballleaguestandings.local.entity.Favorite

@Database(entities = [Favorite::class], version = 3)
abstract class FavoriteDatabase:RoomDatabase() {

    abstract fun favoriteDao():FavoriteDao
}