package com.onidev.footballleaguestandings.viewModel

import androidx.lifecycle.ViewModel
import com.onidev.footballleaguestandings.local.entity.Favorite
import com.onidev.footballleaguestandings.repository.FootballRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

@HiltViewModel
class FavoriteTeamViewModel @Inject constructor(private val footballRepository: FootballRepository): ViewModel() {

    suspend fun getFavo(): Flow<List<Favorite>> {
        return footballRepository.getFavorite()
    }

    suspend fun delete(favorite: Favorite) {
        footballRepository.deleteFavorite(favorite)
    }
}
