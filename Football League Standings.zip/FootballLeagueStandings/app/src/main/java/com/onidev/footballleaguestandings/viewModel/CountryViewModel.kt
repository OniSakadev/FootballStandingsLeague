package com.onidev.footballleaguestandings.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.onidev.footballleaguestandings.BuildConfig
import com.onidev.footballleaguestandings.repository.FootballRepository
import com.onidev.footballleaguestandings.response.listAreas.AreaResponse
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CountryViewModel @Inject constructor(private val footballRepository: FootballRepository) : ViewModel() {

//    private val api: FootballApi = FootballApi.create()

    private val _countryList: MutableLiveData<AreaResponse?> = MutableLiveData()
    val countryList: MutableLiveData<AreaResponse?> = _countryList

    private val _whenLoading: MutableLiveData<Boolean> = MutableLiveData()
    val whenLoading: MutableLiveData<Boolean> = _whenLoading

    fun getCountry() {
        viewModelScope.launch {
            _whenLoading.value = true
            try {
                val response = footballRepository.getAreas(apiKey = BuildConfig.APIKEY)
                _countryList.value = response
            }catch (e: Exception){
                _countryList.value = null
                Log.d("error",e.toString())
            }finally {
                _whenLoading.value = false
            }
        }
    }

    init {
        getCountry()
    }
}