package com.onidev.footballleaguestandings.data

import android.app.Application
import androidx.room.Room
import com.onidev.footballleaguestandings.local.FavoriteDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object Module {
    @Provides
    @Singleton
    fun provideFootball(): FootballApi{
        return Retrofit.Builder()
            .baseUrl("http://api.football-data.org/v4/")
            .addConverterFactory(GsonConverterFactory.create())
            .build().create(FootballApi::class.java)
    }

    @Provides
    @Singleton
    fun provideDatabase(
        context: Application
    ): FavoriteDatabase {
        return Room.databaseBuilder(context.applicationContext, FavoriteDatabase::class.java, "favorite.db")
            .fallbackToDestructiveMigration()
            .build()
    }
}