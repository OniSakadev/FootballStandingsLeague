package com.onidev.footballleaguestandings.local.entity

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Entity(tableName = "favorite")
@Parcelize
data class Favorite(
    @PrimaryKey val id: Int?,
    val logo: String,
    val name: String,
    val venue: String
):Parcelable
