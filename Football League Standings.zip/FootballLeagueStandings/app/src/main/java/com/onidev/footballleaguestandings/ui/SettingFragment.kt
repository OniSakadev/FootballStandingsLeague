package com.onidev.footballleaguestandings.ui

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import com.onidev.footballleaguestandings.R
import com.onidev.footballleaguestandings.databinding.FragmentSettingsBinding
import com.onidev.footballleaguestandings.local.entity.User
import com.onidev.footballleaguestandings.onboarding.screens.FirstScreen
import com.google.gson.Gson

class SettingFragment : Fragment(R.layout.fragment_settings) {
    private val pref by lazy {
        requireActivity().getSharedPreferences("nama", Context.MODE_PRIVATE)
    }

    private val binding : FragmentSettingsBinding by viewBinding()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.topAppBar.setOnClickListener{
            findNavController().navigateUp()
        }

        getData()

        binding.btnSaveUser.setOnClickListener{
            update()
        }

    }

    private fun update() {
        val nameUpdate = binding.etUsername.text

        try {
            val user = User(nameUpdate.toString())
            val gson = Gson().toJson(user)
            pref.edit().putString(FirstScreen.KEY_USER, gson).apply()
            getData()
        }catch (e:Exception){
            Toast.makeText(requireContext(), e.toString(), Toast.LENGTH_SHORT).show()
            return
        }
    }

    fun getData(){
        val user = pref.getString(FirstScreen.KEY_USER, null)?:return
        val currentUser = Gson().fromJson(user, User::class.java)

        binding.etUsername.setText(currentUser?.userName)
    }
}