package com.onidev.footballleaguestandings.response.listLeague


import com.google.gson.annotations.SerializedName

data class LeagueResponse(
    @SerializedName("competitions")
    val competitions: List<Competition>,
    @SerializedName("count")
    val count: Int,
    @SerializedName("filters")
    val filters: Filters
)