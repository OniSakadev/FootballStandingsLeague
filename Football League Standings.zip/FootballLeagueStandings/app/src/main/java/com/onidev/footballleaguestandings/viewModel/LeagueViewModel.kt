package com.onidev.footballleaguestandings.viewModel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.onidev.footballleaguestandings.BuildConfig
import com.onidev.footballleaguestandings.repository.FootballRepository
import com.onidev.footballleaguestandings.response.listLeague.LeagueResponse
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LeagueViewModel @Inject constructor(private val footballRepository: FootballRepository): ViewModel() {

//    private val api: FootballApi = FootballApi.create()

    private val _leagueList: MutableLiveData<LeagueResponse?> = MutableLiveData()
    val leagueList: MutableLiveData<LeagueResponse?> = _leagueList

    private val _whenLoading: MutableLiveData<Boolean> = MutableLiveData()
    val whenLoading: MutableLiveData<Boolean> = _whenLoading

    var leagueId = 0

    fun getLeague() {
        viewModelScope.launch {
            _whenLoading.value = true
            try {
                val response = footballRepository.getCompetition(BuildConfig.APIKEY ,areaId = leagueId)
                _leagueList.value = response
            }catch (e: Exception) {
                _leagueList.value = null
//                Log.d("mberr", e.toString())
            }finally {
                _whenLoading.value = false
            }
        }
    }
}