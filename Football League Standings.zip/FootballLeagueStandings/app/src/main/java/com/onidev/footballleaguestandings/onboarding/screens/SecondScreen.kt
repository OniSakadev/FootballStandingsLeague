package com.onidev.footballleaguestandings.onboarding.screens

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import com.onidev.footballleaguestandings.R
import com.onidev.footballleaguestandings.databinding.FragmentSecondScreenBinding

class SecondScreen : Fragment(R.layout.fragment_second_screen) {

    val binding: FragmentSecondScreenBinding by viewBinding()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        binding.finish2.setOnClickListener{
            findNavController().navigate(R.id.action_viewPagerFragment_to_listCountry)
            onBoardingFinished()
        }
    }
    private fun onBoardingFinished(){
        val sharedPref = requireActivity().getSharedPreferences("onBoarding", Context.MODE_PRIVATE)
        val editor = sharedPref.edit()
        editor.putBoolean("Finished", true)
        editor.apply()
    }
}