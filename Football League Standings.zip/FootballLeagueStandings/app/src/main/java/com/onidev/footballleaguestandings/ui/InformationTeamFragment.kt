package com.onidev.footballleaguestandings.ui

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import coil.load
import com.onidev.footballleaguestandings.R
import com.onidev.footballleaguestandings.adapter.InformationTeamAdapter
import com.onidev.footballleaguestandings.databinding.FragmentInformationTeamBinding
import com.onidev.footballleaguestandings.local.entity.Favorite
import com.onidev.footballleaguestandings.viewModel.DetailTeamViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class InformationTeamFragment : Fragment(R.layout.fragment_information_team) {

    private val viewModel: DetailTeamViewModel by viewModels()
    private val binding: FragmentInformationTeamBinding by viewBinding()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val teamId = arguments?.getInt(KEY_INFO_TEAM) ?: 0

        viewModel.whenLoading.observe(viewLifecycleOwner) {
            binding.progressIndicator.isVisible = it
        }

        binding.topAppBar.setOnMenuItemClickListener {
            when(it.itemId){
                R.id.setting -> {
                    findNavController().navigate(R.id.action_informationTeam_to_fragmentSetting3)
                }
            }
            when(it.itemId){
                R.id.favorite -> {
                    findNavController().navigate(R.id.action_informationTeam_to_favoriteTeamFragment)
                }
            }
            true
        }

        binding.swipe.setOnRefreshListener {
            viewModel.getDetail(teamId)
        }

        binding.topAppBar.setOnClickListener{
            findNavController().navigateUp()
        }

        viewModel.getDetail(teamId)
        viewModel.detailTeam.observe(viewLifecycleOwner) {data ->
            if (data == null) {
                Toast.makeText(requireContext(), "Oops, something wrong!", Toast.LENGTH_SHORT).show()
            }else {
                binding.imageLogoDetail.load(data.crest)
                binding.titleTeam.text = data.name
                binding.venueTeam.text = data.venue

                val adapter = InformationTeamAdapter(data)
                binding.rvListPlayer.adapter = adapter

                lifecycleScope.launch {
                    val checker = viewModel.getData(id)
                    if (checker == null) {
                        binding.fabFavoriteTeam.setImageResource(R.drawable.baseline_favorite_border)
                    }else{
                        binding.fabFavoriteTeam.setImageResource(R.drawable.baseline_favorite)
                    }
                }

                binding.swipe.isRefreshing = false

                binding.fabFavoriteTeam.setOnClickListener{

                    lifecycleScope.launch {
                        val checker = viewModel.getData(id)
                        if (checker == null) {
                            val favo = Favorite(
                                data.id,
                                data.crest,
                                data.name,
                                data.venue
                            )
                            viewModel.getInsert(favo)
                            Toast.makeText(requireContext(), "sekerang menjadi favorit tim kamu", Toast.LENGTH_SHORT).show()
                        }else{
                            viewModel.getDelete(checker)
                            Toast.makeText(requireContext(), "sekarang bukan jadi tim favorit kamu", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }

        }


    }

    companion object{
        const val KEY_INFO_TEAM = "key_info_team"
    }
}