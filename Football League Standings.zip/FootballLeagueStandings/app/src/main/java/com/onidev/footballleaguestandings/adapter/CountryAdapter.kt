package com.onidev.footballleaguestandings.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import by.kirich1409.viewbindingdelegate.viewBinding
import coil.ImageLoader
import coil.decode.SvgDecoder
import coil.load
import com.onidev.footballleaguestandings.R
import com.onidev.footballleaguestandings.databinding.ItemCardBinding
import com.onidev.footballleaguestandings.response.listAreas.Area
import com.onidev.footballleaguestandings.response.listAreas.AreaResponse

class CountryAdapter(private val countryResponse: AreaResponse): RecyclerView.Adapter<CountryAdapter.CountryViewHolder>() {
    var itemClickListener:((Area) -> Unit)? = null

    class CountryViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        private val binding: ItemCardBinding by viewBinding()

        fun bindView(item: Area) = with(binding){
            val imageLoader = ImageLoader.Builder(itemView.context)
                .components {
                    add(SvgDecoder.Factory())
                }
                .build()
            binding.imgLeagueCountry.load(item.flag){
                decoderFactory { result, options, _ -> SvgDecoder(result.source, options) }
                placeholder(R.drawable.empty_flag)
                error(R.drawable.empty_flag)
            }
            txtLeagueCountry.text = item.name
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CountryViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_card, parent , false)
        return CountryViewHolder(view)
    }

    override fun getItemCount(): Int {
        return countryResponse.count
    }

    override fun onBindViewHolder(holder: CountryViewHolder, position: Int) {
        val item = countryResponse.areas[position]
        holder.bindView(item)
        holder.itemView.setOnClickListener{
            itemClickListener?.invoke(item)
        }
    }
}