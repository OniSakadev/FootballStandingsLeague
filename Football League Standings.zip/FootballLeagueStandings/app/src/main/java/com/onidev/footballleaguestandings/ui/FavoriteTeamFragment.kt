package com.onidev.footballleaguestandings.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import androidx.core.os.bundleOf
import androidx.fragment.app.viewModels
import androidx.lifecycle.asLiveData
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import com.onidev.footballleaguestandings.R
import com.onidev.footballleaguestandings.adapter.FavoriteTeamAdapter
import com.onidev.footballleaguestandings.databinding.FragmentFavoriteTeamBinding
import com.onidev.footballleaguestandings.viewModel.FavoriteTeamViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class FavoriteTeamFragment : Fragment(R.layout.fragment_favorite_team) {

    private val binding : FragmentFavoriteTeamBinding by viewBinding()

    private val viewMOdel : FavoriteTeamViewModel by viewModels()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        lifecycleScope.launch {

            viewMOdel.getFavo().asLiveData().observe(viewLifecycleOwner) {favorite ->
                val adapter = FavoriteTeamAdapter(favorite)
                binding.rvFavorite.adapter = adapter

                adapter.itemClickListener = {
                    val bundle = bundleOf(DetailFavoriteFragment.KEY_DATA to it)
                    findNavController().navigate(R.id.action_favoriteTeamFragment_to_detailFavoriteFragment, bundle)
                }

                adapter.removeFav = {fav ->
                    lifecycleScope.launch {
                        viewMOdel.delete(fav)
                    }
                }
            }

        }

        binding.topAppBar.setOnClickListener{
            findNavController().navigateUp()
        }
    }

    companion object{
        const val KEY_FAVO_DATA = "key_favo_data"
    }
}