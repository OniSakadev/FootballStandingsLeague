package com.onidev.footballleaguestandings.ui

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import com.onidev.footballleaguestandings.R
import com.onidev.footballleaguestandings.adapter.StandingsAdapter
import com.onidev.footballleaguestandings.databinding.FragmentStandingsLeagueBinding
import com.onidev.footballleaguestandings.viewModel.StandingsViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class StandingsLeagueFragment : Fragment(R.layout.fragment_standings_league) {

    private val viewModel: StandingsViewModel by activityViewModels()
    private val binding: FragmentStandingsLeagueBinding by viewBinding()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val standingsId = arguments?.getInt(KEY_LIST_STANDINGS) ?: 0

        viewModel.whenLoading.observe(viewLifecycleOwner) {
            binding.progressIndicator.isVisible = it
        }


        binding.topAppBar.setOnMenuItemClickListener {
            when(it.itemId){
                R.id.setting -> {
                    findNavController().navigate(R.id.action_standingsLeague_to_fragmentSetting3)
                }
            }
            when(it.itemId){
                R.id.favorite -> {
                    findNavController().navigate(R.id.action_standingsLeague_to_favoriteTeamFragment)
                }
            }
            true
        }

        binding.swipe.setOnRefreshListener {
            getData(standingsId)
        }

        binding.topAppBar.setOnClickListener {
            findNavController().navigateUp()
        }
        getData(standingsId)

    }

    fun getData(standingsId: Int) {
        viewModel.getStandings(standingsId)
        viewModel.standingsList.observe(viewLifecycleOwner) {
            if (it == null) {
                Toast.makeText(requireContext(), "Oops!, something wrong", Toast.LENGTH_SHORT).show()
            } else {
                val adapter = StandingsAdapter(it)
                binding.rvListTeam.adapter = adapter
                adapter.itemClickListener = {
                    val bundle = bundleOf(InformationTeamFragment.KEY_INFO_TEAM to it)
                    findNavController().navigate(R.id.action_standingsLeague_to_informationTeam, bundle)
                }
            }
            binding.swipe.isRefreshing = false
        }
    }

    companion object {
        const val KEY_LIST_STANDINGS = "key_list_league"
    }
}