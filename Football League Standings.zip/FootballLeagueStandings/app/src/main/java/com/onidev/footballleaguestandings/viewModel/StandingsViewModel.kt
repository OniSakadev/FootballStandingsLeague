package com.onidev.footballleaguestandings.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.onidev.footballleaguestandings.BuildConfig
import com.onidev.footballleaguestandings.repository.FootballRepository
import com.onidev.footballleaguestandings.response.Standings.StandingsResponse
import com.onidev.footballleaguestandings.ui.StandingsLeagueFragment
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class StandingsViewModel @Inject constructor(
    private val footballRepository: FootballRepository,
    savedStateHandle: SavedStateHandle
): ViewModel() {

//    private val api: FootballApi = FootballApi.create()

    val id: Int? = savedStateHandle[StandingsLeagueFragment.KEY_LIST_STANDINGS]

    private val _standingsList: MutableLiveData<StandingsResponse?> = MutableLiveData()
    val standingsList: MutableLiveData<StandingsResponse?> = _standingsList

    private val _whenLoading: MutableLiveData<Boolean> = MutableLiveData()
    val whenLoading: MutableLiveData<Boolean> = _whenLoading

    fun getStandings(id: Int) {
        viewModelScope.launch {
            _whenLoading.value = true
            try {
                val response = footballRepository.getStandings(apiKey = BuildConfig.APIKEY, code = id)
                _standingsList.value = response
            }catch (e: Exception) {
                _standingsList.value = null
                Log.d("CEKERR", e.toString())
            }finally {
                _whenLoading.value = false
            }
        }
    }
}