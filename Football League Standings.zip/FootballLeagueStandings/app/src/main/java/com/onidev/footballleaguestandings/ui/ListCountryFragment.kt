package com.onidev.footballleaguestandings.ui

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import com.onidev.footballleaguestandings.R
import com.onidev.footballleaguestandings.adapter.CountryAdapter
import com.onidev.footballleaguestandings.local.entity.User
import com.onidev.footballleaguestandings.databinding.FragmentListCountryBinding
import com.onidev.footballleaguestandings.onboarding.screens.FirstScreen
import com.onidev.footballleaguestandings.viewModel.CountryViewModel
import com.onidev.footballleaguestandings.viewModel.LeagueViewModel
import com.google.gson.Gson
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ListCountryFragment : Fragment(R.layout.fragment_list_country) {

    private val pref by lazy {
        requireActivity().getSharedPreferences("nama", Context.MODE_PRIVATE)
    }

    private val viewModel: CountryViewModel by activityViewModels()
    private val viewModelLeague: LeagueViewModel by activityViewModels()
    private val binding: FragmentListCountryBinding by viewBinding()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.topAppBar.setOnMenuItemClickListener {
            when(it.itemId){
                R.id.setting -> {
                    findNavController().navigate(R.id.action_listCountry_to_fragmentSetting3)
                }
            }
            when(it.itemId){
                R.id.favorite -> {
                    findNavController().navigate(R.id.action_listCountry_to_favoriteTeamFragment)
                }
            }
            true
        }

        binding.swipe.setOnRefreshListener {
            getData()
        }

        getName()

        viewModel.whenLoading.observe(viewLifecycleOwner) {
            binding.progressIndicator.isVisible = it
        }
        getData()
    }

    fun getData(){
        viewModel.getCountry()
        viewModel.countryList.observe(viewLifecycleOwner) {
            if (it == null) {
                Toast.makeText(requireContext(), "Oops!, something wrong", Toast.LENGTH_SHORT).show()
            } else {
                val adapter = CountryAdapter(it)
                binding.rvListCountry.adapter = adapter
                adapter.itemClickListener = {
                    val bundle = bundleOf(ListLeagueFragment.KEY_LIST_LEAGUE to it.id)
                    viewModelLeague.leagueId = it.id
                    findNavController().navigate(R.id.action_listCountry_to_listLeague, bundle)
                }
            }
            binding.swipe.isRefreshing = false
        }
    }

    fun getName() {
        val user = pref.getString(FirstScreen.KEY_USER, null)?:return
        val currentUser = Gson().fromJson(user, User::class.java)

        binding.user.text = currentUser?.userName
    }
}