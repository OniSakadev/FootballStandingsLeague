package com.onidev.footballleaguestandings.response.detailTeam


import com.google.gson.annotations.SerializedName

data class Contract(
    @SerializedName("start")
    val start: Any,
    @SerializedName("until")
    val until: Any
)