package com.onidev.footballleaguestandings.onboarding.screens

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import android.widget.Toast
import androidx.viewpager2.widget.ViewPager2
import by.kirich1409.viewbindingdelegate.viewBinding
import com.onidev.footballleaguestandings.R
import com.onidev.footballleaguestandings.databinding.FragmentFirstScreenBinding
import com.onidev.footballleaguestandings.local.entity.User
import com.google.gson.Gson

class FirstScreen : Fragment(R.layout.fragment_first_screen) {

    private val pref by lazy {
        requireActivity().getSharedPreferences("nama", Context.MODE_PRIVATE)
    }
    val binding : FragmentFirstScreenBinding by viewBinding()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val viewPager = activity?.findViewById<ViewPager2>(R.id.viewPager)

        binding.next1.setOnClickListener{
            viewPager?.currentItem = 1
            try {
                val user = binding.addUsername.text
                if (user.isNullOrEmpty()){
                    binding.addUsername.error = "add your name"
                    return@setOnClickListener
                }
                insertUser(userName = user.toString())
            }catch (e:Exception){
                Toast.makeText(requireContext(), "Oops!, something wrong!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun insertUser(userName: String?) {
        if (userName.isNullOrEmpty()){
            Toast.makeText(requireContext(), "add your name", Toast.LENGTH_SHORT).show()
            return
        }
        val user = User(userName)
        val gson = Gson().toJson(user)

        pref.edit().putString(FirstScreen.KEY_USER, gson).apply()
    }

    companion object {
        const val KEY_USER = "key_user"
    }

}